<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>

<div class="attribute_list">
    <?php echo $controller->getContent(); ?>
</div>
