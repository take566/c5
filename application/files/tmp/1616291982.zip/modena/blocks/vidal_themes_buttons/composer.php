<?php defined("C5_EXECUTE") or die("Access Denied.");
$view->inc('form.php', ["view" => $view]);