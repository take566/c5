<?php   defined('C5_EXECUTE') or die("Access Denied."); ?>

<div class="alert alert-danger">
   <?php  echo t('<strong>Attention!</strong> Clearing your site\'s content prior to installing this theme is highly recommended.')?>
</div>

<div class="alert alert-warning">
    <?php echo t('<strong>Please note:</strong> Installing demo data may take a while, this is normal, please do not refresh your browser during installation.') ?>
</div>