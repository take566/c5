<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<?php $this->inc('elements/sub-page-header.php'); ?>

<section>
    <?php print $innerContent; ?>
</section>

<?php $this->inc('elements/footer.php'); ?>
