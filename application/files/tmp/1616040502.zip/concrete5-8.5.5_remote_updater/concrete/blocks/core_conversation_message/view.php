<?php defined('C5_EXECUTE') or die("Access Denied."); ?>
<?php
Loader::element('conversation/message/topic', array("message" => $message));
