<?php

return [
    'installed' => false,

    'cache' => [
        'enabled' => false,
    ],
];
