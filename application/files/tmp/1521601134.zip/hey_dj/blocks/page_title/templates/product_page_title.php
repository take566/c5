<?php  defined('C5_EXECUTE') or die("Access Denied."); ?>
<<?php echo $formatting;?> class="product-title js-matchHeight"><?php echo h($title)?></<?php echo $formatting;?>>

